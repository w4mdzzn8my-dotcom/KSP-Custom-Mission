"""Build an isolated Hermes Duna carrier candidate; never installs or edits a game.

Inputs are read-only. Output must be a NEW directory outside the supplied KSP
GameData tree. Geometry and nominal budgets are engineering evidence, not flight QA.
"""
import argparse
import copy
import hashlib
import json
import math
import uuid
import zipfile
from pathlib import Path
from build_landers import Node, parse, output, vector, fmt, parent_first

BASE_SHA = "c62df20350aab85ae5b04ba43a742b8220f9d53b3490c55ec0c197117c450273"
G0 = 9.80665
CUSTOM = {"MegaCrewDunaBridge": "sspx-core-375-1", "MegaCrewDunaStores": "sspx-cargo-container-375-1"}


def digest(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def add(a,b): return tuple(x+y for x,y in zip(a,b))
def sub(a,b): return tuple(x-y for x,y in zip(a,b))
def dot(a,b): return sum(x*y for x,y in zip(a,b))
def norm(a): return math.sqrt(dot(a,a))
def rotate(q,v):
    x,y,z,w=q; a=(x,y,z)
    c=(y*v[2]-z*v[1], z*v[0]-x*v[2], x*v[1]-y*v[0])
    cc=(y*c[2]-z*c[1], z*c[0]-x*c[2], x*c[1]-y*c[0])
    return tuple(v[i]+2*w*c[i]+2*cc[i] for i in range(3))
def facing(a,b):
    a=tuple(x/norm(a) for x in a); b=tuple(x/norm(b) for x in b); d=dot(a,b)
    if d < -0.999999: return (0,0,1,0) if abs(a[2])<.9 else (0,1,0,0)
    c=(a[1]*b[2]-a[2]*b[1], a[2]*b[0]-a[0]*b[2], a[0]*b[1]-a[1]*b[0]); q=(*c,1+d)
    length=norm(q); return tuple(x/length for x in q)
def node(prefab,name):
    raw=vector(prefab.get("node_stack_"+name)); return raw[:3],raw[3:6],int(raw[6]) if len(raw)>6 else 1


def generate(cache_path,base_path,destination,lf_tanks=2):
    if lf_tanks not in (2,3,4): raise ValueError("Use two, three or four main LF tanks")
    cache_path=cache_path.resolve(); base_path=base_path.resolve(); destination=destination.resolve()
    if destination.exists(): raise ValueError("Output must be a new directory; no overwrite is permitted")
    # A caller cannot point output into any part of the read-only game's root.
    game_root=cache_path.parent.parent
    if destination==game_root or game_root in destination.parents:
        raise ValueError("Output cannot be inside the input game installation")
    if digest(base_path)!=BASE_SHA: raise ValueError("Unexpected baseline craft hash")
    cache=parse(cache_path.read_text()); catalog={p.get("name"):p for n in cache.children for p in n.nodes("PART")}
    densities={p.get("name"):float(p.get("density")) for n in cache.children for p in n.nodes("RESOURCE_DEFINITION")}
    for custom,source in CUSTOM.items():
        p=copy.deepcopy(catalog[source]);p.set("name",custom)
        if custom=="MegaCrewDunaBridge":
            for module in p.nodes("MODULE"):
                if module.get("name")=="ModuleCommand": module.set("minimumCrew",1)
            if not any(n.get("name")=="ModuleSAS" for n in p.nodes("MODULE")):
                n=Node("MODULE");n.set("name","ModuleSAS");n.set("SASServiceLevel",3);p.children.append(n)
        else:
            p.children=[n for n in p.children if n.name!="RESOURCE" and not(n.name=="MODULE" and n.get("name")=="ModuleB9PartSwitch" and n.get("moduleID")=="cargoSwitch")]
            for name,amount in [("Food",2808),("Water",1872),("Glykerol",100)]:
                n=Node("RESOURCE");n.set("name",name);n.set("amount",amount);n.set("maxAmount",amount);p.children.append(n)
        catalog[custom]=p
    parts=[]; names={}; joints=[]
    def part(name,pos,rot=(0,0,0,1)):
        prefab=catalog[name]; key=name.replace("_",".")+"_"+str(980000000+len(parts)); n=Node("PART")
        for k,v in [("part",key),("partName","Part"),("persistentId",981000000+len(parts)),("pos",fmt(pos)),("attPos","0,0,0"),("attPos0",fmt(pos)),("rot",fmt(rot)),("attRot","0,0,0,1"),("attRot0",fmt(rot)),("mir","1,1,1"),("symMethod","Radial"),("autostrutMode","Grandparent"),("rigidAttachment","False"),("istg",0 if name=="nuclearEngine" else -1),("dstg",0 if name=="nuclearEngine" else -1),("sidx",-1),("sqor",-1),("sepI",-1),("attm",0)]: n.add(k,v)
        # KSP instantiates modules from prefabs; resources serialize finite initial inventory.
        n.children=copy.deepcopy(prefab.nodes("RESOURCE"))
        for r in n.nodes("RESOURCE"):
            if r.get("name")=="Oxidizer":r.set("amount",0)
        parts.append(n);names[key]=name; return n
    def attach(parent,pnode,name,cnode,rot=(0,0,0,1)):
        pp=catalog[names[parent.get("part")]]; cp=catalog[name]
        a,an,asz=node(pp,pnode); b,bn,bsz=node(cp,cnode)
        pq=vector(parent.get("rot")); target=add(vector(parent.get("pos")),rotate(pq,a)); pos=sub(target,rotate(rot,b))
        if dot(rotate(pq,an),rotate(rot,bn))>-.999999: raise ValueError("Non-opposed stack normals")
        if asz!=bsz: raise ValueError("Mismatched stack sizes")
        child=part(name,pos,rot); pk,ck=parent.get("part"),child.get("part")
        parent.add("link",ck);parent.add("attN",pnode+","+ck+"_"+"|".join(map(str,a)))
        child.add("attN",cnode+","+pk+"_"+"|".join(map(str,b)))
        joints.append({"parent":pk,"child":ck,"parent_node":pnode,"child_node":cnode})
        return child
    def surface(parent,name,point,inward):
        raw=vector(catalog[name].get("node_attach"));q=facing(raw[3:6],inward)
        child=part(name,sub(point,rotate(q,raw[:3])),q)
        child.set("attm",1);child.add("srfN","srfAttach,"+parent.get("part"));parent.add("link",child.get("part"));return child
    core=part("MegaCrewDunaBridge",(0,80,0)); previous=core
    for name in ["sspx-habitation-375-1","sspx-lab-375-1","sspx-expandable-centrifuge-375-1","sspx-tube-375-1"]:
        previous=attach(previous,"bottom",name,"top")
    tube=previous
    previous=attach(previous,"bottom","sspx-adapter-25-375-2","bottom",(0,0,1,0))
    cryo=attach(previous,"top","CRY-2300Freezer","top");previous=cryo
    # Stores sit aft of the cryobay: the original command-to-cryo walking chain is unchanged.
    previous=attach(previous,"bottom","sspx-adapter-25-375-2","top")
    stores=attach(previous,"bottom","MegaCrewDunaStores","top")
    previous=attach(stores,"bottom","sspx-adapter-25-375-2","bottom",(0,0,1,0))
    pnode="top"
    for _ in range(4): previous=attach(previous,pnode,"batteryBankLarge","top");pnode="bottom"
    previous=attach(previous,"bottom","adapterMk3-Size2","top")
    for _ in range(lf_tanks):previous=attach(previous,"bottom","mk3FuselageLF_100","top")
    tank=previous
    previous=attach(previous,"bottom","adapterMk3-Size2","bottom",(0,0,1,0))
    quad=attach(previous,"top","adapterLargeSmallQuad","top")
    for i in range(1,5):attach(quad,"bottom0"+str(i),"nuclearEngine","top")
    front=attach(core,"top","sspx-adapter-25-375-2","bottom")
    attach(front,"top","dockingPortLarge","bottom")
    # Diametrically balanced auxiliary hardware; these do not establish deployed clearance.
    for angle in range(0,360,90):
        r=math.radians(angle);out=(math.cos(r),0,math.sin(r));inward=tuple(-x for x in out)
        def mount(parent,name,y,radius):return surface(parent,name,(radius*out[0],y,radius*out[2]),inward)
        y=float(tube.get("pos").split(",")[1]);mount(tube,"largeSolarPanel",y+2,1.875)
        mount(tube,"foldingRadLarge",y-2,1.875)
        for dy in [-1,1]:mount(stores,"rtg",float(stores.get("pos").split(",")[1])+dy,1.875)
        for parent in [core,stores]:
            y=float(parent.get("pos").split(",")[1]);mount(parent,"rcsTankRadialLong",y,1.875)
            mount(parent,"RCSBlock_v2",y+.65,1.875)
    root=Node("ROOT")
    for k,v in [("ship","Hermes Duna Carrier Prototype"),("version","1.12.5"),("description","Duna carrier engineering candidate. Not flight-qualified. No atmospheric lander or recovery vehicle. Keep centrifuge stopped until deployed clearance is checked; fit actual SOI and finite burns before flight. Command-to-cryo FreeIVA chain retained; supplies aft of cryo. Requires MegaCrew DunaVehicle.cfg."),("type","VAB"),("size","40,90,40"),("persistentId",980000000),("rot","0,0,0,1"),("missionFlag","Squad/Flags/default"),("vesselType","Ship")]:root.add(k,v)
    root.children=parts;parent_first(root)
    totals={};dry=0
    for p in parts:
        dry+=float(catalog[names[p.get("part")]].get("mass"))
        for r in p.nodes("RESOURCE"):totals[r.get("name")]=totals.get(r.get("name"),0)+float(r.get("amount"))
    wet=dry+4*.09375+sum(densities[name]*amount for name,amount in totals.items())
    fuel=totals["LiquidFuel"]*densities["LiquidFuel"];usable=.85*fuel
    ve=800*G0;thrust=240;burnrate=thrust/ve
    food_need=24*30*2*1.5;water_need=24*30*2*1.0
    report={"candidate":"Hermes Duna Carrier Prototype","runtime_verified":False,"mission_playable":False,"base_craft_sha256":BASE_SHA,"part_count":len(parts),"main_lf_tanks":lf_tanks,"dry_parts_t":dry,"crew_mass_assumption_t":.375,"wet_with_four_crew_t":wet,"resources":totals,"cryo_spaces":10,"planned_freezes":12,"glykerol_required_units":60,"food_baseline_units":food_need,"water_with_hygiene_baseline_units":water_need,"food_margin_percent":100*(totals['Food']/food_need-1),"water_margin_percent":100*(totals['Water']/water_need-1),"engine_count":4,"vacuum_thrust_kN":thrust,"vacuum_isp_s":800,"fuel_reserve_fraction":.15,"ideal_delta_v_to_15_percent_reserve_m_s":ve*math.log(wet/(wet-usable)),"ideal_delta_v_with_15t_extra_payload_m_s":ve*math.log((wet+15)/(wet+15-usable)),"full_usable_fuel_burn_seconds":usable/burnrate,"nominal_rtg_EC_per_second":6,"two_frozen_nominal_EC_per_second":2*10/60,"four_radiators_nominal_EC_per_second":2,"instant_battery_freeze_events_3000_EC":totals['ElectricCharge']/3000,"stack_joint_count":len(joints),"limitations":["Nominal prefab masses; deployed centrifuge/module mass changes and geometry require runtime verification","Tank flow and fuel accessibility through adapters/crew modules require KSP verification","Finite long burns, SOI fitting and periapsis-kick strategy not yet implemented","No atmospheric Duna lander, surface/ascent fuel, return capsule or qualified lander storage","RTG/solar/cryo background and high-warp power behavior unverified; acceleration remains disabled","Surface mounting and deployed solar/radiator/centrifuge clearance require native inspection","Four-crew overlap and manual tasks spend the finite reserve; baseline assumes exactly two unfrozen throughout","No flight controls, actual route, freeze/thaw or game-save evidence follows from this report"],"stack_joints":joints}
    if totals.get("Oxidizer",0)!=0 or totals["Glykerol"]<60 or totals["Food"]<1.3*food_need or totals["Water"]<1.3*water_need:raise ValueError("Inventory budget failed")
    cfg_source=Path(__file__).with_name("DunaVehicle.cfg")
    cfg_text=cfg_source.read_text()
    # Parse before output creation; a missing/malformed companion is an error.
    parse(cfg_text)
    destination.mkdir(parents=True)
    cfg=destination/"GameData/MegaCrew/DunaVehicle.cfg";cfg.parent.mkdir(parents=True);cfg.write_text(cfg_text)
    report["custom_parts_cfg_sha256"]=digest(cfg)
    report["input_cache_sha256"]=digest(cache_path)
    ship=destination/"Ships/VAB/Hermes Duna Carrier Prototype.craft";ship.parent.mkdir(parents=True);ship.write_text(output(root))
    report["craft_sha256"]=digest(ship)
    doc=destination/"docs/DUNA-VEHICLE-DESIGN.json";doc.parent.mkdir(parents=True);doc.write_text(json.dumps(report,indent=2)+"\n")
    print(json.dumps({k:v for k,v in report.items() if k!='stack_joints'},indent=2))
    return root,catalog,report


SEED_SHA="0071eacf3a1b38a63c611fe2a65877ea2f62f6076b7e97d22e9cdf58b412cf40"

def make_fixture(root,catalog,report,seed_zip,destination,save_name="MegaCrew Duna Prototype"):
    # A NEW fictional starting scenario, never a conversion of a personal save.
    with zipfile.ZipFile(seed_zip) as z:
        game=parse(z.read("saves/MegaCrew Practice/persistent.sfs").decode()).nodes("GAME")[0]
    game.set("Title",save_name+" (SANDBOX)")
    game.set("Description","Unqualified Duna carrier commissioning in 150 km Kerbin orbit. Plan before starting the campaign. No executable Duna route or lander is supplied yet.")
    flight=game.nodes("FLIGHTSTATE")[0];vessel=flight.nodes("VESSEL")[0]
    template=copy.deepcopy(vessel.nodes("PART")[0])
    vessel.children=[n for n in vessel.children if n.name!="PART"]
    vessel.set("pid",uuid.uuid5(uuid.NAMESPACE_URL,"hermes-duna-prototype:"+hashlib.sha256(output(root).encode()).hexdigest()).hex)
    vessel.set("persistentId",982000000);vessel.set("name",root.get("ship"));vessel.set("type",root.get("vesselType","Ship"))
    vessel.set("ref",980000000);vessel.set("stg",1)
    parts=root.nodes("PART");ids={p.get("part"):i for i,p in enumerate(parts)}
    parents={child:i for i,p in enumerate(parts) for k,child in p.values if k=="link"}
    names=[n.get("name") for n in game.nodes("ROSTER")[0].nodes("KERBAL")]
    assert len(names)==4
    origin=vector(parts[0].get("pos"))
    for i,p in enumerate(parts):
        name=p.get("part").rsplit("_",1)[0].replace(".","_");n=Node("PART")
        n.values=[(k,val) for k,val in template.values if k not in ("crew","attN","srfN")]
        for k,val in [("name",name),("cid",i),("uid",p.get("part").rsplit("_",1)[1]),("mid",982000000),("persistentId",p.get("persistentId")),("parent",parents.get(p.get("part"),0)),("position",fmt(sub(vector(p.get("pos")),origin))),("rotation",p.get("rot")),("attm",p.get("attm")),("mass",catalog[name].get("mass")),("modMass",0),("modCost",0),("istg",p.get("istg")),("dstg",p.get("dstg")),("sidx",-1)]:n.set(k,val)
        for k,val in p.values:
            if k=="attN":
                label,target=val.split(",",1);n.add("attN",label+", "+str(ids[target.rsplit("_",1)[0]]))
            elif k=="srfN":
                label,target=val.split(",",1);n.set("srfN",label+", "+str(ids[target]))
        if n.get("srfN") is None:n.set("srfN","None, -1")
        if i==0:
            for crew in names:n.add("crew",crew)
        n.children=copy.deepcopy(p.nodes("RESOURCE"))+copy.deepcopy(catalog[name].nodes("MODULE"))
        for child in n.children:
            if child.name=="RESOURCE":child.set("flowState",child.get("flowState","True"))
            elif child.name=="MODULE":
                child.set("isEnabled","True")
                if child.get("name") in ("ModuleEngines","ModuleEnginesFX"):
                    child.set("EngineIgnited","False");child.set("currentThrottle",0)
                if child.get("name") in ("ModuleDeployableSolarPanel","ModuleDeployableRadiator"):child.set("deployState","RETRACTED")
        vessel.children.append(n)
    target=destination/"saves"/save_name/"persistent.sfs"
    if target.exists():raise ValueError("Refusing to overwrite an existing commissioning save")
    target.parent.mkdir(parents=True);target.write_text(game.text())
    evidence={"seed_zip_sha256":SEED_SHA,"new_save":save_name,"vessel_type":root.get("vesselType","Ship"),"persistent_sfs_sha256":digest(target),"crew":names,"all_four_initially_assigned_to_command":True,"orbit_altitude_m":150000,"orbit_body":"Kerbin","start_ut":100000,"parts":len(parts),"native_scenario_initialization_required":True,"in_game_load_verified":False,"mission_playable":False,"note":"New disposable commissioning fixture only. Warp remains disabled. No route, campaign start, nodes, frozen crew or completed maintenance are fabricated."}
    (destination/"docs/DUNA-FIXTURE.json").write_text(json.dumps(evidence,indent=2)+"\n")
    print(json.dumps(evidence,indent=2))

if __name__=="__main__":
    p=argparse.ArgumentParser(description=__doc__);p.add_argument("--cache",required=True,type=Path);p.add_argument("--base-craft",required=True,type=Path);p.add_argument("--output-root",required=True,type=Path);p.add_argument("--seed-zip",type=Path,help="Optional pristine published 0.3.0 archive: creates a NEW disposable orbital commissioning save");p.add_argument("--lf-tanks",type=int,choices=[2,3,4],default=2);a=p.parse_args()
    if a.seed_zip is not None and digest(a.seed_zip)!=SEED_SHA:raise ValueError("Unexpected commissioning seed archive")
    root,catalog,report=generate(a.cache,a.base_craft,a.output_root,a.lf_tanks)
    if a.seed_zip is not None:make_fixture(root,catalog,report,a.seed_zip,a.output_root.resolve())
