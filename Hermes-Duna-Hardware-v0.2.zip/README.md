# Hermes Duna expedition hardware review — v0.2

**Development candidate only. Not installed, flight-qualified, or a playable Duna mission.**
Hamish's running Luna window is off limits. Do not copy this into an active game, launch another host KSP, replace a running save, or merge the draft PR to test it.

This v0.2 supersedes hardware v0.1 and the older carrier-only v0.3 for commissioning. Basil’s independent review caught the inherited ProtoVessel `type = Station`; the shared generator now copies the craft’s vesselType (`Ship`), and both the full-fleet and default carrier audits assert it. Existing saves were not edited.

## New hardware and commissioning scenario

The combined craft contains 127 parts: three-tank Hermes, a forward Ares descent/ascent lander, and two matching Kerbin recovery capsules on opposite radial docking mounts. Two recovery capsules provide two assigned seats each, covering all four expedition crew. The nominal mass calculation counts those same four people only once.

`Ships/VAB/Hermes Duna Expedition Fleet Prototype.craft` is a new construction candidate. Its three port pairs have coincident, opposed attachment faces and matching actual stock node types. That does not establish native pre-attached state, successful separation/redocking, hatch traversal, deployed panel/centrifuge clearance or flight stability.

`saves/MegaCrew Duna Fleet Prototype/persistent.sfs` is a NEW disposable sandbox commissioning scenario at 150 km Kerbin orbit, UT 100000. All four named crew are awake in the command deck. Engines/throttle are off and time warp is disabled. It is generated only from the hash-pinned pristine published 0.3.0 fixture, never a personal or running save. No campaign, frozen crew, completed maintenance, maneuver nodes or fabricated DeepFreeze scenarios/readiness are inserted. Normal KSP scenario initialization is required during future native QA.

`GameData/MegaCrew/` contains four **new part clones** defined in two configs: dedicated command deck/stores, Ares cabin and recovery cabin. Existing stock/SSPX definitions are unchanged. All assets and DLLs come from the existing dependency profile; none are bundled. Stock HECS2 avionics provide each payload with a level-3 SAS module, subject to actual control/power/runtime validation. This does not claim to solve the owner's current SAS problem in their different running game.

## Nominal fleet budget

- Wet mass with four crew: **320.36 t**.
- Four primary LV-N engines, three main 10,000-unit LF tanks plus stock adapter LF.
- Primary transfer fuel: **32,250 LF units**, with 15% held back.
- Ideal primary vacuum delta-v: **4,380 m/s**. The lander's additional 2,880 LF units and its oxidizer are excluded from this transfer calculation.
- Payload propellant/food/water resources serialize `flowState = False`; payload engine inverse stages serialize -1. These are **requested stowage locks**, not evidence that KSP applied them. Verify actual locks and safe separation before deliberately unlocking payload supplies/fuel and arming its engines. Batteries remain available. Native resource connectivity, engine selection and separation behavior are unverified.

The previous unloaded carrier figure must not be used for this fleet. All masses are nominal prefab/resource estimates. Deployed module/B9 mass changes and dynamic/thermal behavior require measurement. The current Duna planner deliberately rejects the mixed-engine fleet; explicit primary propulsion/tank selection is a required source task. Do not bypass that refusal or count reserved lander fuel as carrier fuel.

## Ares lander: important open failure

The 31-part candidate uses two Thud radial engines, two X200-32 tanks, retained 2.5 m ablative shield, four landing legs, four main/two drogue chutes, stock avionics, solar/batteries/RCS and a three-seat cabin with two assigned crew. Finite cabin provisions cover two crew for 14 standard days at current campaign rates.

Its wet mass with two crew is **43.60 t**. A deliberately conservative, constant **275 s** Isp design bound gives **2,914 m/s** while holding 10% of propellant. The provisional allocation is **1,000 m/s deorbit/powered descent + 1,800 ascent + 200 rendezvous = 3,000 m/s**. **It misses that allocation by about 86 m/s.** The 305 s vacuum upper bound passes, but it cannot certify a real atmospheric trajectory. The 3 m/s² gravity, Isp bound and maneuver allocations are explicit design inputs, not measured Duna telemetry. No parachute braking or ablator mass-loss performance is credited.

The conservative shortfall remains visible in the report. It was not hidden by keeping an unrealistically small descent placeholder or by changing a test to assert mission success. Actual pressure-dependent engine performance and finite descent/ascent must be modeled/verified, or the propulsion design revised, before this lander can be accepted. Shield/exhaust clearance, entry stability, tall lander ground stability, heating, high-terrain chute behavior and ascent rendezvous are all unverified.

## Kerbin recovery capsules

Each 18-part capsule has a retained heat shield, four main/two drogue chutes, avionics, solar/battery, 130 MonoPropellant units and finite four-day provisions for two assigned people. Its nominal wet mass with two crew is **5.42 t**, with approximately **188 m/s** ideal vacuum RCS delta-v leaving 20% MonoPropellant. This is a **low-Kerbin-orbit** recovery candidate after the carrier has captured, not a direct interplanetary-entry design. Actual RCS translation, deorbit, thermal entry, chute clearance/deployment, hatch access and touchdown must be tested.

## Source and reproducibility

`components/Carrier/` is the new standalone three-tank carrier. `components/Payloads/` contains the separate lander/capsule craft and detailed inventory/bounds. `inputs/Original-Two-Tank-Carrier-Report.json` preserves the published comparison baseline. Tools and static audits are included; no plugin DLL is replaced.

The cache argument is a read-only matching KSP 1.12.5 ModuleManager cache. Every generator refuses an existing output folder and output inside that cache's game root. Use new artifact folders outside all game directories. Example audits:

```sh
python3 tests/verify_duna_payloads.py \
  --cache /path/to/qa-game/GameData/ModuleManager.ConfigCache \
  --carrier-report inputs/Original-Two-Tank-Carrier-Report.json \
  --candidate components/Payloads

python3 tests/verify_duna_fleet.py \
  --cache /path/to/qa-game/GameData/ModuleManager.ConfigCache \
  --candidate .
```

To reproduce: run `tools/build_duna_vehicle.py` with the supplied baseline craft and `--lf-tanks 3`; run `tools/build_duna_payloads.py` with the original comparison report; then `tools/build_duna_fleet.py` with those NEW output folders and optional `--seed-zip` pointing to pristine `Hermes-Practice-v0.3.0.zip`. Use `--help` for exact arguments. The archive's required SHA-256 is `0071eacf3a1b38a63c611fe2a65877ea2f62f6076b7e97d22e9cdf58b412cf40`; it is not bundled here.

## Evidence and remaining mission work

Independent static audits pass: 127 unique connected parts, 40 coincident/opposed/matching-size stack joints, 86 surface graph edges, three matching dock-port pairs, independent resource/mass-flow calculations, four-person mass accounting and serialized requested payload locks/staging. The full NEW fixture's 127 parent/ID/resource snapshots, crew, engine and warp state also pass static audit. Standalone payload audits cover actual attachment coordinates, leg orientation, thrust symmetry, stock SAS modules and finite supplies. These are source/data/model checks, not aerodynamic or live gameplay evidence.

A shared fixture-generation bug was found and fixed: it previously forced every resource flowState to true. It now preserves explicit stowage locks. Do not replace the new full-fleet fixture with the older 57-part carrier-only commissioning save.

Remaining: fix the conservative lander budget; explicit live primary-engine/tank scope; native ModuleManager/craft/save/separation/clearance/SAS/flow validation; real Kerbin–Duna–Kerbin SOI/finite-burn trajectory; detached surface-sortie crew/needs/duty ownership; actual cryosleep, background power and accelerated watch behavior; maintenance/stories and the single undisclosed planned emergency. Native game testing remains deferred while the owner plays Luna. The original installations, personal saves, server Universe and IPv4 fix/backup remain untouched.
