"""Independent static audit of fleet graph, port pairs and primary-only budget."""
import argparse
import collections
import hashlib
import json
import math
from pathlib import Path
import sys
sys.path.insert(0,str(Path(__file__).resolve().parents[1]/'tools'))
from build_landers import parse,vector
from verify_duna_payloads import qmatrix,plus,distance,partname,integrated_dv

def verify(cache_path,folder):
    cache=parse(cache_path.read_text());cat={p.get('name'):p for n in cache.children for p in n.nodes('PART')};density={p.get('name'):float(p.get('density')) for n in cache.children for p in n.nodes('RESOURCE_DEFINITION')}
    for name,base in [('MegaCrewDunaBridge','sspx-core-375-1'),('MegaCrewDunaStores','sspx-cargo-container-375-1'),('MegaCrewAresCabin','mk1-3pod'),('MegaCrewRecoveryCabin','mk1-3pod')]:cat[name]=cat[base]
    path=folder/'Ships/VAB/Hermes Duna Expedition Fleet Prototype.craft';parts=parse(path.read_text()).nodes('PART');report=json.loads((folder/'docs/DUNA-FLEET.json').read_text())
    assert hashlib.sha256(path.read_bytes()).hexdigest()==report['craft_sha256']
    assert len(parts)==report['parts']==127
    keys=[p.get('part') for p in parts];byid={p.get('part'):p for p in parts};order={k:i for i,k in enumerate(keys)}
    assert len(byid)==127 and len(set(p.get('persistentId') for p in parts))==127
    parents={};connections=set();stack=0;surfaces=0;totals=collections.defaultdict(float);dry=0
    for p in parts:
        key=p.get('part');q=vector(p.get('rot'));prefab=cat[partname(p)];assert abs(sum(x*x for x in q)-1)<1e-7
        dry+=float(prefab.get('mass'))
        for r in p.nodes('RESOURCE'):
            amount=float(r.get('amount'));assert 0<=amount<=float(r.get('maxAmount')) and math.isfinite(amount);totals[r.get('name')]+=amount
        for k,val in p.values:
            if k=='link':assert val in byid and val not in parents and order[key]<order[val];parents[val]=key;connections.add(frozenset([key,val]))
            elif k=='attN':
                label,other=val.split(',',1);other=other.rsplit('_',1)[0];assert other in byid
                if order[key]>order[other]:continue
                child=byid[other];reciprocal=[v for k,v in child.values if k=='attN' and v.split(',',1)[1].rsplit('_',1)[0]==key];assert len(reciprocal)==1
                a=vector(prefab.get('node_stack_'+label));b=vector(cat[partname(child)].get('node_stack_'+reciprocal[0].split(',',1)[0]));assert (a[6] if len(a)>6 else 1)==(b[6] if len(b)>6 else 1)
                assert distance(plus(vector(p.get('pos')),qmatrix(q,a[:3])),plus(vector(child.get('pos')),qmatrix(vector(child.get('rot')),b[:3])))<1e-5
                assert sum(x*y for x,y in zip(qmatrix(q,a[3:6]),qmatrix(vector(child.get('rot')),b[3:6])))<-.999999
                stack+=1
        if p.get('srfN'):
            parent=p.get('srfN').split(',',1)[1];assert parent in byid;surfaces+=1
    assert len(parents)==126 and stack+surfaces==126 and keys[0] not in parents
    for pair in report['port_pairs']:
        a,b=[byid[pair[k]] for k in ['carrier_port','payload_port']]
        assert frozenset([a.get('part'),b.get('part')]) in connections
        types=[next(m.get('nodeType') for m in cat[partname(p)].nodes('MODULE') if m.get('name')=='ModuleDockingNode') for p in [a,b]];assert types[0]==types[1]
        for p in [a,b]:assert any(m.get('name')=='ModuleDockingNode' and m.get('state')=='PreAttached' for m in p.nodes('MODULE'))
    assert len(report['port_pairs'])==3
    roles=report['roles'];payload_ids=[key for p in roles['payloads'] for key in p['part_ids']];carrier_ids=roles['carrier_part_ids']
    assert len(set(payload_ids))==len(payload_ids) and not set(payload_ids)&set(carrier_ids)
    assert len(payload_ids)==31+18+18 and len(carrier_ids)==58 and len(set(keys)-set(payload_ids)-set(carrier_ids))==2
    assert len(roles['carrier_engine_ids'])==4 and all(partname(byid[k])=='nuclearEngine' for k in roles['carrier_engine_ids'])
    for key in payload_ids:
        p=byid[key];assert p.get('istg')=='-1' and p.get('dstg')=='-1'
        for r in p.nodes('RESOURCE'):
            if r.get('name') in ('LiquidFuel','Oxidizer','MonoPropellant','Food','Water'):assert r.get('flowState')=='False'
    primary_lf=sum(float(r.get('amount')) for k in roles['carrier_liquid_fuel_tank_ids'] for r in byid[k].nodes('RESOURCE') if r.get('name')=='LiquidFuel')
    assert primary_lf==32250 and report['payload_LF_units_excluded_from_transfer_budget']==2880
    wet=dry+.375+sum(density[k]*amount for k,amount in totals.items())
    assert abs(wet-report['wet_with_four_crew_t'])<1e-8 and dict(totals)==report['all_resources']
    dv=integrated_dv(wet,.85*primary_lf*density['LiquidFuel'],800);assert abs(dv-report['primary_ideal_delta_v_to_15_percent_LF_reserve_m_s'])<1e-5
    # Each recovery capsule has two actual seats allocated, covering four people;
    # no simultaneous six-crew mass charge is hidden in the fleet calculation.
    assert report['four_crew_mass_counted_once_t']==.375 and sum('recovery capsule' in x['role'] for x in roles['payloads'])==2
    assert abs(report['nominal_uncrewed_center_of_mass_m'][0])<1e-5 and abs(report['nominal_uncrewed_center_of_mass_m'][2])<1e-3
    assert not report['runtime_verified'] and not report['physically_loaded_or_separated'] and not report['mission_playable'] and not report['native_flow_lock_application_verified']
    save=folder/'saves/MegaCrew Duna Fleet Prototype/persistent.sfs'
    if save.exists():
        game=parse(save.read_text()).nodes('GAME')[0];flight=game.nodes('FLIGHTSTATE')[0];vessel=flight.nodes('VESSEL')[0];snapshots=vessel.nodes('PART')
        assert vessel.get('type')=='Ship'
        assert len(snapshots)==127 and flight.get('UT')=='100000' and game.get('Title')=='MegaCrew Duna Fleet Prototype (SANDBOX)'
        assert vessel.nodes('ORBIT')[0].get('SMA')=='750000' and vessel.nodes('ORBIT')[0].get('REF')=='1'
        crew=[v for k,v in snapshots[0].values if k=='crew'];assert crew==['Hamish Kerman','Basil Kerman','Ada Kerman','Vikram Kerman']
        assert not any(k=='crew' for p in snapshots[1:] for k,v in p.values)
        for p,snapshot in zip(parts,snapshots):
            assert snapshot.get('name')==partname(p) and snapshot.get('uid')==p.get('part').rsplit('_',1)[1]
            expected_parent=order[parents[p.get('part')]] if p.get('part') in parents else 0
            assert int(snapshot.get('parent'))==expected_parent
            for resource in p.nodes('RESOURCE'):
                saved=next(r for r in snapshot.nodes('RESOURCE') if r.get('name')==resource.get('name'))
                assert saved.get('amount')==resource.get('amount') and saved.get('flowState')==resource.get('flowState','True')
            for m in snapshot.nodes('MODULE'):
                if m.get('name') in ('ModuleEngines','ModuleEnginesFX'):assert m.get('EngineIgnited')=='False' and m.get('currentThrottle')=='0'
        rules=game.nodes('PARAMETERS')[0].nodes('FLIGHT')[0];assert rules.get('CanTimeWarpHigh')=='False' and rules.get('CanTimeWarpLow')=='False'
        fixture=json.loads((folder/'docs/DUNA-FIXTURE.json').read_text());assert hashlib.sha256(save.read_bytes()).hexdigest()==fixture['persistent_sfs_sha256'] and not fixture['in_game_load_verified']
        assert not any(n.get('name') in ('DeepFreeze','HermesCampaign') for n in game.nodes('SCENARIO'))
        print('PASS: NEW full-fleet orbital fixture, 127 parent/ID/resource snapshots, four command crew, preserved payload flow locks, engines off, warp disabled, no fabricated campaign/cryo initialization.')
    print('PASS: 127 unique connected parts,',stack,'exact stack joints,',surfaces,'surface edges, three type-matched port pairs, payload staging/resource-lock requests, primary-only propellant budget and four-crew mass. Native load/docking/flow unverified.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cache',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);a=p.parse_args();verify(a.cache,a.candidate)
