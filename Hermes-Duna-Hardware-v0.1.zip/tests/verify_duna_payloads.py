"""Static verification of actual exported payload craft and fleet budget, not flight QA."""
import argparse
import collections
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile

TOOLS=Path(__file__).resolve().parents[1]/'tools'
sys.path.insert(0,str(TOOLS))
from build_landers import parse, vector

def qmatrix(q,p):
    x,y,z,w=q
    return ((1-2*y*y-2*z*z)*p[0]+2*(x*y-z*w)*p[1]+2*(x*z+y*w)*p[2],2*(x*y+z*w)*p[0]+(1-2*x*x-2*z*z)*p[1]+2*(y*z-x*w)*p[2],2*(x*z-y*w)*p[0]+2*(y*z+x*w)*p[1]+(1-2*x*x-2*y*y)*p[2])
def plus(a,b):return tuple(x+y for x,y in zip(a,b))
def distance(a,b):return math.sqrt(sum((x-y)**2 for x,y in zip(a,b)))
def partname(p):return p.get('part').rsplit('_',1)[0].replace('.','_')
def integrated_dv(wet,used,isp):
    steps=100000;step=used/steps
    return sum(isp*9.80665*step/(wet-step*(i+.5)) for i in range(steps))

def verify(cache_path,carrier_path,candidate):
    cache=parse(cache_path.read_text());catalog={p.get('name'):p for n in cache.children for p in n.nodes('PART')}
    densities={p.get('name'):float(p.get('density')) for n in cache.children for p in n.nodes('RESOURCE_DEFINITION')}
    report=json.loads((candidate/'docs/DUNA-PAYLOADS.json').read_text());carrier=json.loads(carrier_path.read_text())
    cfg=candidate/'GameData/MegaCrew/DunaPayloads.cfg';clones=parse(cfg.read_text()).children
    assert len(clones)==2
    for clone in clones:
        assert clone.name=='+PART[mk1-3pod]:NEEDS[CommunityResourcePack]:FINAL'
        catalog[clone.get('@name')]=catalog['mk1-3pod']
        assert {r.get('name') for r in clone.nodes('RESOURCE')}=={'Food','Water'}
    payload_mass=0
    for label,quantity in [('lander',1),('kerbin_recovery_capsule',2)]:
        r=report[label];path=candidate/'Ships/VAB'/r['craft'];root=parse(path.read_text());parts=root.nodes('PART')
        assert hashlib.sha256(path.read_bytes()).hexdigest()==r['craft_sha256']
        keys=[p.get('part') for p in parts];byid={p.get('part'):p for p in parts};order={k:i for i,k in enumerate(keys)}
        assert len(byid)==len(parts)==r['parts'] and len(set(p.get('persistentId') for p in parts))==len(parts)
        parents={};stack_count=0;surface_count=0;resources=collections.defaultdict(float);dry=0
        for p in parts:
            key=p.get('part');prefab=catalog[partname(p)];q=vector(p.get('rot'));assert abs(sum(v*v for v in q)-1)<1e-7
            dry+=float(prefab.get('mass'))
            for resource in p.nodes('RESOURCE'):
                amount=float(resource.get('amount'));assert 0<=amount<=float(resource.get('maxAmount')) and math.isfinite(amount)
                resources[resource.get('name')]+=amount
            for k,target in p.values:
                if k=='link':assert target in byid and target not in parents and order[key]<order[target];parents[target]=key
                if k=='attN':
                    name,target=target.split(',',1);other=target.rsplit('_',1)[0]
                    assert other in byid
                    if order[key]>order[other]:continue
                    remote=byid[other];reciprocal=[val for k,val in remote.values if k=='attN' and val.split(',',1)[1].rsplit('_',1)[0]==key];assert len(reciprocal)==1
                    a=vector(prefab.get('node_stack_'+name));b=vector(catalog[partname(remote)].get('node_stack_'+reciprocal[0].split(',',1)[0]))
                    assert (a[6] if len(a)>6 else 1)==(b[6] if len(b)>6 else 1)
                    assert distance(plus(vector(p.get('pos')),qmatrix(q,a[:3])),plus(vector(remote.get('pos')),qmatrix(vector(remote.get('rot')),b[:3])))<1e-5
                    assert sum(x*y for x,y in zip(qmatrix(q,a[3:6]),qmatrix(vector(remote.get('rot')),b[3:6])))<-.999999
                    stack_count+=1
            if p.get('srfN'):
                parent=p.get('srfN').split(',',1)[1];assert parent in byid
                anchor=plus(vector(p.get('pos')),qmatrix(q,vector(prefab.get('node_attach'))[:3]))
                record=next(a for a in r['surface_anchors'] if a['part']==key)
                assert distance(anchor,record['point'])<1e-5
                assert abs(math.hypot(anchor[0],anchor[2])-record['radius'])<1e-5
                if partname(p)=='landingLeg1-2':assert distance(qmatrix(q,(0,1,0)),(0,1,0))<1e-7
                surface_count+=1
        assert len(parents)==len(parts)-1 and keys[0] not in parents and stack_count+surface_count==len(parts)-1
        assert stack_count==len(r['stack_joints']) and surface_count==len(r['surface_anchors'])
        assert dict(resources)==r['resources'];wet=dry+sum(densities[k]*x for k,x in resources.items())
        assert abs(wet-r['wet_uncrewed_t'])<1e-8 and abs(wet+.1875-r['wet_with_crew_t'])<1e-8
        payload_mass+=quantity*wet
        counts=collections.Counter(partname(p) for p in parts)
        assert counts['HeatShield2']==1 and resources['Ablator']==800 and counts['probeStackSmall']==1 and counts['dockingPortLarge' if label=='lander' else 'dockingPort2']==1
        assert next(n for n in catalog['probeStackSmall'].nodes('MODULE') if n.get('name')=='ModuleSAS').get('SASServiceLevel')=='3'
        custom=partname(parts[0]);clone=next(c for c in clones if c.get('@name')==custom)
        assert {r.get('name'):float(r.get('amount')) for r in clone.nodes('RESOURCE')}=={name:resources[name] for name in ['Food','Water']}
        assert counts['parachuteRadial']==4 and counts['radialDrogue']==2
        if label=='lander':
            assert counts['radialLiquidEngine1-2']==2 and counts['landingLeg1-2']==4 and counts['Rockomax32_BW']==2
            engines=[p for p in parts if partname(p)=='radialLiquidEngine1-2']
            assert all(distance(qmatrix(vector(p.get('rot')),(0,1,0)),(0,1,0))<1e-8 for p in engines)
            assert abs(sum(vector(p.get('pos'))[0] for p in engines))<1e-7 and abs(sum(vector(p.get('pos'))[2] for p in engines))<1e-7
            fuel=resources['LiquidFuel']*densities['LiquidFuel']+resources['Oxidizer']*densities['Oxidizer']
            assert abs(fuel-32)<1e-8 and abs(resources['LiquidFuel']/resources['Oxidizer']-.9/1.1)<1e-12
            for engine in engines:
                module=engine.nodes('MODULE')[0];assert module.get('EngineIgnited')=='False' and module.get('currentThrottle')=='0'
            dv=integrated_dv(wet+.1875,.9*fuel,275)
            assert abs(dv-r['design_delta_v_to_reserve_m_s'])<1e-5
            assert r['conservative_provisional_budget_met']==(dv>=sum(r['provisional_budget_m_s'].values())) and r['design_initial_twr']>1.5
            assert r['conservative_provisional_budget_met'] is False and abs(r['conservative_budget_shortfall_m_s']-(3000-dv))<1e-5
            assert r['parachute_performance_credit']==0 and r['heatshield_mass_loss_credit']==0
            assert resources['Food']>=2*14*1.5 and resources['Water']>=2*14
        else:
            assert not any('Engine' in partname(p) for p in parts)
            dv=integrated_dv(wet+.1875,.8*resources['MonoPropellant']*densities['MonoPropellant'],240)
            assert abs(dv-r['vacuum_rcs_ideal_delta_v_to_reserve_m_s'])<1e-5 and dv>120
            assert r['required_quantity']==2 and r['occupied_seats_per_capsule']==2 and not r['designed_for_direct_interplanetary_entry']
            assert resources['Food']>=2*4*1.5 and resources['Water']>=2*4
        assert not r['runtime_verified']
        print('PASS:',path.name,len(parts),'parts,',stack_count,'stack joints,',surface_count,'surface anchors; independent inventory/propellant/geometry checks.')
    fleet=report['fleet_budget'];assert abs(payload_mass-fleet['payload_uncrewed_t'])<1e-8 and fleet['four_crew_counted_once']
    wet=carrier['wet_with_four_crew_t']+payload_mass;used=.85*carrier['resources']['LiquidFuel']*densities['LiquidFuel']
    assert abs(wet-fleet['current_two_tank_carrier_plus_payload_t'])<1e-8
    assert abs(integrated_dv(wet,used,800)-fleet['current_carrier_ideal_delta_v_to_15_percent_reserve_m_s'])<1e-5
    assert not fleet['payloads_physically_integrated_or_docked'] and not report['mission_playable']
    for path,key in [(cache_path,'cache_sha256'),(carrier_path,'carrier_report_sha256'),(cfg,'custom_parts_cfg_sha256')]:assert hashlib.sha256(path.read_bytes()).hexdigest()==report[key]
    with tempfile.TemporaryDirectory() as tmp:
        tmp=Path(tmp);fake=tmp/'fake-game/GameData/ModuleManager.ConfigCache';fake.parent.mkdir(parents=True);fake.write_text('')
        for output in [candidate,tmp/'fake-game/forbidden']:
            result=subprocess.run([sys.executable,str(TOOLS/'build_duna_payloads.py'),'--cache',str(fake),'--carrier-report',str(carrier_path),'--output-root',str(output)],capture_output=True,text=True)
            assert result.returncode!=0
        assert not (tmp/'fake-game/forbidden').exists()
    print('PASS: four-crew fleet mass counted once; actual payload mass lowers carrier delta-v; safe output refusals. Static only: no aerodynamic, native-load or mission qualification.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cache',type=Path,required=True);p.add_argument('--carrier-report',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);a=p.parse_args();verify(a.cache,a.carrier_report,a.candidate)
