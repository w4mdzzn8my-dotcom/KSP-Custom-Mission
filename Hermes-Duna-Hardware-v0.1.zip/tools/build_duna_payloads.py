"""Generate isolated atmospheric lander/recovery candidates, not flight qualification."""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
from build_landers import Node, parse, output, parent_first, fmt, vector
from build_duna_vehicle import rotate, add, sub, node, facing

class Craft:
    def __init__(self,catalog,title,base):
        self.catalog,self.title,self.base=catalog,title,base
        self.parts=[];self.names={};self.joints=[];self.surface=[]
    def part(self,name,pos,rot=(0,0,0,1)):
        n=Node('PART');identity=self.base+len(self.parts);key=name.replace('_','.')+'_'+str(identity)
        for k,val in [('part',key),('partName','Part'),('persistentId',identity+10000),('pos',fmt(pos)),('attPos','0,0,0'),('attPos0',fmt(pos)),('rot',fmt(rot)),('attRot','0,0,0,1'),('attRot0',fmt(rot)),('mir','1,1,1'),('symMethod','Radial'),('autostrutMode','Grandparent'),('rigidAttachment','False'),('istg',-1),('dstg',-1),('sidx',-1),('sqor',-1),('sepI',-1),('attm',0)]:n.add(k,val)
        n.children=copy.deepcopy(self.catalog[name].nodes('RESOURCE'))
        if name=='radialLiquidEngine1-2':
            n.set('istg',0);n.set('dstg',0)
            engine=Node('MODULE');engine.set('name','ModuleEngines');engine.set('EngineIgnited','False');engine.set('currentThrottle',0);n.children.append(engine)
        self.parts.append(n);self.names[key]=name;return n
    def stack(self,parent,pnode,name,cnode,q=(0,0,0,1)):
        a,an,asz=node(self.catalog[self.names[parent.get('part')]],pnode);b,bn,bsz=node(self.catalog[name],cnode)
        pq=vector(parent.get('rot'));assert asz==bsz
        assert sum(x*y for x,y in zip(rotate(pq,an),rotate(q,bn)))<-.999999
        child=self.part(name,sub(add(vector(parent.get('pos')),rotate(pq,a)),rotate(q,b)),q)
        parent.add('link',child.get('part'));parent.add('attN',pnode+','+child.get('part')+'_'+'|'.join(map(str,a)))
        child.add('attN',cnode+','+parent.get('part')+'_'+'|'.join(map(str,b)))
        self.joints.append((parent.get('part'),pnode,child.get('part'),cnode));return child
    def radial(self,parent,name,y,angle,radius=1.25):
        r=math.radians(angle);out=(math.cos(r),0,math.sin(r));raw=vector(self.catalog[name].get('node_attach'))
        # Preserve stock leg pitch: yaw alone keeps local +Y vertical. Most other
        # parts have horizontal attach normals, which are aligned to the cylinder.
        if name=='landingLeg1-2':
            yaw=math.pi/2-r;q=(0,math.sin(yaw/2),0,math.cos(yaw/2))
        else:q=facing(raw[3:6],tuple(-v for v in out))
        point=(radius*out[0],y,radius*out[2]);child=self.part(name,sub(point,rotate(q,raw[:3])),q)
        parent.add('link',child.get('part'));child.set('attm',1);child.add('srfN','srfAttach,'+parent.get('part'))
        self.surface.append({'part':child.get('part'),'parent':parent.get('part'),'point':point,'radius':radius,'preserved_leg_pitch':name=='landingLeg1-2'})
        return child
    def save(self,path,description,densities,crew):
        root=Node('ROOT')
        for k,val in [('ship',self.title),('version','1.12.5'),('description',description),('type','VAB'),('size','10,20,10'),('persistentId',self.base),('rot','0,0,0,1'),('missionFlag','Squad/Flags/default'),('vesselType','Lander' if crew==2 and 'Lander' in self.title else 'Ship')]:root.add(k,val)
        root.children=self.parts;parent_first(root);path.parent.mkdir(parents=True,exist_ok=True);path.write_text(output(root))
        dry=sum(float(self.catalog[self.names[n.get('part')]].get('mass')) for n in self.parts);resources={}
        for p in self.parts:
            for r in p.nodes('RESOURCE'):resources[r.get('name')]=resources.get(r.get('name'),0)+float(r.get('amount'))
        wet=dry+sum(densities[k]*v for k,v in resources.items())
        return {'craft':path.name,'craft_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'parts':len(self.parts),'dry_prefab_t':dry,'wet_uncrewed_t':wet,'assumed_crew':crew,'wet_with_crew_t':wet+crew*.09375,'resources':resources,'stack_joints':self.joints,'surface_anchors':self.surface,'runtime_verified':False}

def build(cache_path,carrier_path,destination):
    cache_path=cache_path.resolve();destination=destination.resolve()
    if destination.exists():raise ValueError('Output must be a new directory')
    game=cache_path.parent.parent
    if destination==game or game in destination.parents:raise ValueError('Output cannot be inside the input game')
    cache=parse(cache_path.read_text());cat={p.get('name'):p for n in cache.children for p in n.nodes('PART')}
    density={p.get('name'):float(p.get('density')) for n in cache.children for p in n.nodes('RESOURCE_DEFINITION')}
    carrier=json.loads(carrier_path.read_text())
    # New prefab names carry finite surface/recovery rations without changing
    # any stock pod or relying on resource injection when a save is loaded.
    for name,food,water in [('MegaCrewAresCabin',42,28),('MegaCrewRecoveryCabin',12,8)]:
        clone=copy.deepcopy(cat['mk1-3pod']);clone.set('name',name)
        for resource,amount in [('Food',food),('Water',water)]:
            r=Node('RESOURCE');r.set('name',resource);r.set('amount',amount);r.set('maxAmount',amount);clone.children.append(r)
        cat[name]=clone
    # Build in memory first; all parts are stock. No fabricated resource definitions.
    lander=Craft(cat,'Hermes Ares Duna Lander Prototype',990000000)
    command=lander.part('MegaCrewAresCabin',(0,15,0));tank=lander.stack(command,'bottom','Rockomax32_BW','top')
    lower=lander.stack(tank,'bottom','Rockomax32_BW','top');shield=lander.stack(lower,'bottom','HeatShield2','top')
    avionics=lander.stack(command,'top','probeStackSmall','bottom');adapter=lander.stack(avionics,'top','largeAdapter2','bottom');lander.stack(adapter,'top','dockingPortLarge','bottom')
    # Radial engines retain a clear central heat-shield face; exact model/exhaust
    # geometry, stability and heating must be checked in KSP before crew flight.
    tank_y=vector(tank.get('pos'))[1];lower_y=vector(lower.get('pos'))[1]
    for angle in [0,180]:lander.radial(tank,'radialLiquidEngine1-2',tank_y+.5,angle)
    for angle in [45,135,225,315]:
        lander.radial(lower,'landingLeg1-2',lower_y-.5,angle)
        lander.radial(command,'parachuteRadial',15.35,angle,radius=.8)
        lander.radial(tank,'RCSBlock_v2',tank_y,angle)
    for angle in [90,270]:lander.radial(command,'radialDrogue',15.65,angle,radius=.65)
    for angle in [0,90,180,270]:
        lander.radial(tank,'solarPanels5',tank_y+1,angle)
        lander.radial(tank,'batteryBankMini',tank_y-.6,angle)
    capsule=Craft(cat,'Hermes Kerbin Recovery Capsule Prototype',992000000)
    pod=capsule.part('MegaCrewRecoveryCabin',(0,8,0));capsule.stack(pod,'bottom','HeatShield2','top')
    avionics=capsule.stack(pod,'top','probeStackSmall','bottom');capsule.stack(avionics,'top','dockingPort2','bottom')
    for angle in [45,135,225,315]:
        capsule.radial(pod,'parachuteRadial',8.35,angle,radius=.8)
        capsule.radial(pod,'solarPanels5',7.9,angle,radius=1.05)
    for angle in [0,180]:
        capsule.radial(pod,'radialDrogue',8.65,angle,radius=.65)
        capsule.radial(pod,'rcsTankRadialLong',7.85,angle,radius=1.05)
        capsule.radial(pod,'batteryBankMini',7.8,angle+90,radius=1.05)
    cfg_text=Path(__file__).with_name('DunaPayloads.cfg').read_text();parse(cfg_text)
    destination.mkdir(parents=True)
    cfg=destination/'GameData/MegaCrew/DunaPayloads.cfg';cfg.parent.mkdir(parents=True);cfg.write_text(cfg_text)
    l=lander.save(destination/'Ships/VAB/Hermes Ares Duna Lander Prototype.craft','Two-crew atmospheric descent/ascent engineering candidate, NOT flight qualified. Full propulsive descent budget; no parachute credit. Retain heat shield; radial engines. Landing leg, hatch, exhaust, heating and chute clearance require native testing. No autonomous landing or certified trajectory.',density,2)
    c=capsule.save(destination/'Ships/VAB/Hermes Kerbin Recovery Capsule Prototype.craft','Two-crew Kerbin recovery engineering candidate, NOT flight qualified. Carry TWO capsules for all four crew. Recover only after Hermes captures into verified low Kerbin orbit. RCS deorbit; no interplanetary direct-entry certification. Thermal, chute, hatch and landing tests required.',density,2)
    # Explicit design targets, not a declaration of stock Duna constants or a
    # measured ascent/drag model. No parachute/ablation mass-loss credit.
    design_isp=275;gravity=3.0;fuel=(l['resources']['LiquidFuel']+l['resources']['Oxidizer'])*.005;wet=l['wet_with_crew_t'];reserve=.1*fuel
    l.update({'design_isp_floor_s':design_isp,'design_surface_gravity_m_s2':gravity,'propellant_t':fuel,'propellant_reserve_fraction':.1,'design_delta_v_to_reserve_m_s':design_isp*9.80665*math.log(wet/(wet-fuel+reserve)),'vacuum_delta_v_to_reserve_m_s':305*9.80665*math.log(wet/(wet-fuel+reserve)),'design_thrust_kN':240*design_isp/305,'design_initial_twr':240*design_isp/305/(wet*gravity),'provisional_budget_m_s':{'deorbit_and_powered_descent':1000,'ascent':1800,'rendezvous':200},'parachute_performance_credit':0,'heatshield_mass_loss_credit':0})
    mono=c['resources']['MonoPropellant']*density['MonoPropellant'];wet=c['wet_with_crew_t'];c.update({'mono_reserve_fraction':.2,'vacuum_rcs_ideal_delta_v_to_reserve_m_s':240*9.80665*math.log(wet/(wet-.8*mono)),'required_quantity':2,'occupied_seats_per_capsule':2,'deorbit_test_budget_m_s':120,'designed_for_direct_interplanetary_entry':False})
    payload=l['wet_uncrewed_t']+2*c['wet_uncrewed_t'];original_wet=carrier['wet_with_four_crew_t'];usable=carrier['resources']['LiquidFuel']*.005*.85
    # Crew already counted once on the carrier; never count those same Kerbals
    # again inside the three uncrewed hardware payload masses.
    fleet={'payload_uncrewed_t':payload,'four_crew_counted_once':True,'current_two_tank_carrier_plus_payload_t':original_wet+payload,'current_carrier_ideal_delta_v_to_15_percent_reserve_m_s':800*9.80665*math.log((original_wet+payload)/(original_wet+payload-usable)),'payloads_physically_integrated_or_docked':False,'additional_tank_sensitivity':[]}
    for count in [1,2]:
        extra_dry=count*float(cat['mk3FuselageLF_100'].get('mass'));extra_fuel=count*10000*density['LiquidFuel'];wet=original_wet+payload+extra_dry+extra_fuel
        fleet['additional_tank_sensitivity'].append({'additional_mk3_10000LF_tanks':count,'wet_t':wet,'ideal_delta_v_to_15_percent_reserve_m_s':800*9.80665*math.log(wet/(wet-usable-.85*extra_fuel)),'status':'mass sensitivity only; extra tanks are NOT built or installed by this payload package'})
    l['provisional_budget_total_m_s']=sum(l['provisional_budget_m_s'].values())
    l['conservative_provisional_budget_met']=l['design_delta_v_to_reserve_m_s']>=l['provisional_budget_total_m_s']
    l['conservative_budget_shortfall_m_s']=max(0,l['provisional_budget_total_m_s']-l['design_delta_v_to_reserve_m_s'])
    l['vacuum_upper_bound_budget_met']=l['vacuum_delta_v_to_reserve_m_s']>=l['provisional_budget_total_m_s']
    assert l['design_initial_twr']>1.5 and c['vacuum_rcs_ideal_delta_v_to_reserve_m_s']>c['deorbit_test_budget_m_s']
    report={'candidate':'Hermes atmospheric payloads v0.1','custom_parts_cfg_sha256':hashlib.sha256(cfg.read_bytes()).hexdigest(),'cache_sha256':hashlib.sha256(cache_path.read_bytes()).hexdigest(),'carrier_report_sha256':hashlib.sha256(carrier_path.read_bytes()).hexdigest(),'lander':l,'kerbin_recovery_capsule':c,'fleet_budget':fleet,'mission_playable':False,'limitations':['Current campaign vessel ownership/ration/room adapters need an explicit surface-sortie integration before detached needs and duties can be claimed','Lander fails the current 3000 m/s provisional allocation at the 275 s constant-Isp conservative bound; the vacuum upper bound passing is NOT ascent/descent certification','No native craft load, physical storage/docking, FreeIVA traversal, descent/ascent, heating, parachute, leg stability, exhaust clearance or recovery result','Duna gravity/ISP and maneuver allocations here are explicit conservative DESIGN ASSUMPTIONS, not actual body/engine-curve telemetry or flight certification','Chutes use stock defaults; low ambient pressure/high terrain may prevent deployment. No chute braking is credited in the provisional powered descent budget','RCS recovery budget assumes already captured low Kerbin orbit, no direct interplanetary entry','Payload fuel is reserved for lander use; a future assembled-fleet planner must distinguish carrier engines/tanks from stowed payload engines/tanks','Existing planet-search adapter rejects mixed engine/propellant families; no bypass or complete assembled-fleet planning claim','Carrier budget must be reconciled to the actual route and correction reserves after physical integration']}
    (destination/'docs').mkdir();(destination/'docs/DUNA-PAYLOADS.json').write_text(json.dumps(report,indent=2)+'\n')
    print(json.dumps({k:v for k,v in report.items() if k not in ['lander','kerbin_recovery_capsule']},indent=2));print('Lander',l['wet_with_crew_t'],'t',l['design_delta_v_to_reserve_m_s'],'m/s conservative design; capsule',c['wet_with_crew_t'],'t',c['vacuum_rcs_ideal_delta_v_to_reserve_m_s'],'m/s ideal vacuum RCS')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--carrier-report',type=Path,required=True);p.add_argument('--output-root',type=Path,required=True);a=p.parse_args();build(a.cache,a.carrier_report,a.output_root)
