"""Assemble new carrier/payload craft data outside all game installations.

Port-face attachment geometry is construction evidence, NOT native docking QA.
"""
import argparse
import copy
import hashlib
import json
import math
from pathlib import Path
from build_landers import Node,parse,output,fmt,vector,parent_first
from build_duna_vehicle import rotate,add,sub,facing,make_fixture,SEED_SHA

def pn(p):return p.get('part').rsplit('_',1)[0].replace('.','_')
def qmul(a,b):
    x,y,z,w=a;X,Y,Z,W=b
    return (w*X+x*W+y*Z-z*Y,w*Y-x*Z+y*W+z*X,w*Z+x*Y-y*X+z*W,w*W-x*X-y*Y-z*Z)
def digest(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def build(cache_path,carrier,payloads,destination,seed_zip=None):
    cache_path=cache_path.resolve();destination=destination.resolve()
    if destination.exists():raise ValueError('Output must be a new directory')
    game=cache_path.parent.parent
    if destination==game or game in destination.parents:raise ValueError('No output inside the input game installation')
    cache=parse(cache_path.read_text());cat={p.get('name'):p for n in cache.children for p in n.nodes('PART')};density={p.get('name'):float(p.get('density')) for n in cache.children for p in n.nodes('RESOURCE_DEFINITION')}
    if seed_zip is not None and digest(seed_zip)!=SEED_SHA:raise ValueError('Unexpected commissioning seed ZIP')
    for name,base in [('MegaCrewDunaBridge','sspx-core-375-1'),('MegaCrewDunaStores','sspx-cargo-container-375-1'),('MegaCrewAresCabin','mk1-3pod'),('MegaCrewRecoveryCabin','mk1-3pod')]:
        cat[name]=copy.deepcopy(cat[base]);cat[name].set('name',name)
        p=cat[name]
        if name=='MegaCrewDunaBridge':
            next(m for m in p.nodes('MODULE') if m.get('name')=='ModuleCommand').set('minimumCrew',1)
            p.children=[m for m in p.children if not(m.name=='MODULE' and m.get('name')=='ModuleSAS')]
            m=Node('MODULE');m.set('name','ModuleSAS');m.set('SASServiceLevel',3);p.children.append(m)
        else:
            if name=='MegaCrewDunaStores':
                p.children=[n for n in p.children if n.name!='RESOURCE' and not(n.name=='MODULE' and n.get('name')=='ModuleB9PartSwitch' and n.get('moduleID')=='cargoSwitch')]
                provisions=[('Food',2808),('Water',1872),('Glykerol',100)]
            else:provisions=[('Food',42 if name=='MegaCrewAresCabin' else 12),('Water',28 if name=='MegaCrewAresCabin' else 8)]
            for resource,amount in provisions:
                r=Node('RESOURCE');r.set('name',resource);r.set('amount',amount);r.set('maxAmount',amount);p.children.append(r)
    root=parse((carrier/'Ships/VAB/Hermes Duna Carrier Prototype.craft').read_text());parts=root.nodes('PART');carrier_parts=list(parts)
    assert sum(pn(p)=='mk3FuselageLF_100' for p in parts)==3
    roles={'carrier_part_ids':[p.get('part') for p in parts],'carrier_engine_ids':[p.get('part') for p in parts if pn(p)=='nuclearEngine'],'carrier_liquid_fuel_tank_ids':[p.get('part') for p in parts if any(r.get('name')=='LiquidFuel' for r in p.nodes('RESOURCE'))],'payloads':[]}
    pairs=[]
    def serialized_node(part,attachnode):
        n=vector(cat[pn(part)].get('node_stack_'+attachnode));return n[:3]
    def newport(parent,angle,identity):
        theta=math.radians(angle);out=(math.cos(theta),0,math.sin(theta));q=facing((0,-1,0),tuple(-x for x in out));pos=(1.875*out[0],vector(parent.get('pos'))[1],1.875*out[2]);p=Node('PART')
        for k,val in [('part','dockingPort2_'+str(identity)),('partName','Part'),('persistentId',identity+10000),('pos',fmt(pos)),('attPos','0,0,0'),('attPos0',fmt(pos)),('rot',fmt(q)),('attRot','0,0,0,1'),('attRot0',fmt(q)),('mir','1,1,1'),('symMethod','Radial'),('autostrutMode','Grandparent'),('rigidAttachment','False'),('istg',-1),('dstg',-1),('sidx',-1),('sqor',-1),('sepI',-1),('attm',1),('srfN','srfAttach,'+parent.get('part'))]:p.add(k,val)
        parent.add('link',p.get('part'));parts.append(p);return p
    def mount(path,portname,carrier_port,q,identity,role):
        payload=parse(path.read_text());children=copy.deepcopy(payload.nodes('PART'));mapping={p.get('part'):pn(p).replace('_','.')+'_'+str(identity+i) for i,p in enumerate(children)}
        for i,p in enumerate(children):
            p.set('part',mapping[p.get('part')]);p.set('persistentId',identity+10000+i)
            for j,(key,val) in enumerate(p.values):
                if key=='link':p.values[j]=(key,mapping[val])
                elif key=='attN':
                    node,target=val.split(',',1);original,suffix=target.rsplit('_',1);p.values[j]=(key,node+','+mapping[original]+'_'+suffix)
                elif key=='srfN':node,target=val.split(',',1);p.values[j]=(key,node+','+mapping[target])
            # Stowed payload engine arms are removed from the carrier's space-bar stage.
            # Native arming/undocking must be tested; no automation is installed.
            p.set('istg',-1);p.set('dstg',-1)
            for resource in p.nodes('RESOURCE'):
                if resource.get('name') in ('LiquidFuel','Oxidizer','MonoPropellant','Food','Water'):resource.set('flowState','False')
        byid={p.get('part'):p for p in children};port=next(p for p in children if pn(p)==portname)
        parent={v:p.get('part') for p in children for k,v in p.values if k=='link'}
        # Reverse the original command->nose chain, so the nose port can parent
        # the cabin and the carrier remains the sole craft root.
        chain=[];key=port.get('part')
        while key in parent:chain.append((parent[key],key));key=parent[key]
        for previous,next_key in chain:
            p=byid[previous];p.values=[(k,v) for k,v in p.values if not(k=='link' and v==next_key)];byid[next_key].add('link',previous)
        target=add(vector(carrier_port.get('pos')),rotate(vector(carrier_port.get('rot')),serialized_node(carrier_port,'top')))
        local=add(vector(port.get('pos')),rotate(vector(port.get('rot')),serialized_node(port,'top')))
        offset=sub(target,rotate(q,local))
        for p in children:
            p.set('pos',fmt(add(offset,rotate(q,vector(p.get('pos'))))));p.set('attPos0',p.get('pos'))
            p.set('rot',fmt(qmul(q,vector(p.get('rot')))));p.set('attRot0',p.get('rot'))
        for a,b in [(carrier_port,port),(port,carrier_port)]:
            a.add('attN','top,'+b.get('part')+'_'+'|'.join(map(str,serialized_node(a,'top'))))
            module=Node('MODULE');module.set('name','ModuleDockingNode');module.set('state','PreAttached');a.children.append(module)
        carrier_port.add('link',port.get('part'));parts.extend(children)
        pairs.append({'carrier_port':carrier_port.get('part'),'payload_port':port.get('part'),'role':role,'native_pre_attached_state_verified':False})
        roles['payloads'].append({'role':role,'source_craft_sha256':digest(path),'part_ids':[p.get('part') for p in children],'reserved_resource_part_ids':[p.get('part') for p in children if p.nodes('RESOURCE')]})
    forward=next(p for p in parts if pn(p)=='dockingPortLarge')
    mount(payloads/'Ships/VAB/Hermes Ares Duna Lander Prototype.craft','dockingPortLarge',forward,(1,0,0,0),996000000,'Duna descent/ascent lander')
    tube=next(p for p in parts if pn(p)=='sspx-tube-375-1')
    for i,angle in enumerate([45,225]):
        theta=math.radians(angle);out=(math.cos(theta),0,math.sin(theta));port=newport(tube,angle,986000000+i)
        mount(payloads/'Ships/VAB/Hermes Kerbin Recovery Capsule Prototype.craft','dockingPort2',port,facing((0,1,0),tuple(-x for x in out)),997000000+i*10000,'Kerbin recovery capsule '+str(i+1))
    root.set('ship','Hermes Duna Expedition Fleet Prototype');root.set('description','Pre-attached construction candidate: three-tank Hermes, forward Ares lander, paired recovery capsules. NOT flight-qualified. Native separation, deployed clearances, mixed-engine fuel scope, finite transfer burns and detached crew/campaign accounting remain pending. Payload engine staging is disabled in this carrier craft. No mission-ready claim.');root.set('size','50,130,50');root.children=parts;parent_first(root)
    dry=0;resources={};weighted=[0,0,0]
    for p in parts:
        mass=float(cat[pn(p)].get('mass'))
        dry+=mass
        for r in p.nodes('RESOURCE'):resources[r.get('name')]=resources.get(r.get('name'),0)+float(r.get('amount'));mass+=density[r.get('name')]*float(r.get('amount'))
        pos=add(vector(p.get('pos')),rotate(vector(p.get('rot')),vector(cat[pn(p)].get('CoMOffset','0,0,0'))))
        for i in range(3):weighted[i]+=mass*pos[i]
    wet_uncrewed=dry+sum(density[name]*x for name,x in resources.items());wet=wet_uncrewed+.375
    primary_lf=sum(float(r.get('amount')) for p in carrier_parts for r in p.nodes('RESOURCE') if r.get('name')=='LiquidFuel');usable=.85*primary_lf*density['LiquidFuel']
    manifest={'candidate':'Hermes Duna Expedition Fleet Prototype','parts':len(parts),'carrier_main_lf_tanks':3,'four_crew_mass_counted_once_t':.375,'wet_with_four_crew_t':wet,'dry_prefab_t':dry,'all_resources':resources,'reserved_carrier_LF_units':primary_lf,'payload_LF_units_excluded_from_transfer_budget':resources['LiquidFuel']-primary_lf,'primary_ideal_delta_v_to_15_percent_LF_reserve_m_s':800*9.80665*math.log(wet/(wet-usable)),'nominal_uncrewed_center_of_mass_m':[x/wet_uncrewed for x in weighted],'port_pairs':pairs,'roles':roles,'stowed_payload_propellant_and_ration_flow_locks_requested':True,'native_flow_lock_application_verified':False,'physically_loaded_or_separated':False,'mission_playable':False,'runtime_verified':False,'limitations':['Serialized payload propellant/ration flow locks require native validation and deliberate unlock after verified separation before payload operation','Construction node geometry is not native docking/separation or deployment clearance evidence','Mass/CoM nominal prefab estimates only; B9 variants, deployed modules, resource flow and native dynamics require validation','Lander and recovery propellants are reserved; current mixed-engine planner refuses this assembly until explicit primary propulsion scope is implemented','Detached campaign, needs, room and crew accounting require explicit sortie/recovery integration','No stock ephemeris/SOI/finite burn, cryosleep/high-rate, atmospheric landing/ascent/recovery or four-crew campaign qualification']}
    destination.mkdir(parents=True);ship=destination/'Ships/VAB/Hermes Duna Expedition Fleet Prototype.craft';ship.parent.mkdir(parents=True);ship.write_text(output(root))
    configs=destination/'GameData/MegaCrew';configs.mkdir(parents=True)
    for source in [carrier/'GameData/MegaCrew/DunaVehicle.cfg',payloads/'GameData/MegaCrew/DunaPayloads.cfg']:(configs/source.name).write_bytes(source.read_bytes())
    manifest['craft_sha256']=digest(ship);manifest['input_cache_sha256']=digest(cache_path);manifest['input_carrier_report_sha256']=digest(carrier/'docs/DUNA-VEHICLE-DESIGN.json');manifest['input_payload_report_sha256']=digest(payloads/'docs/DUNA-PAYLOADS.json')
    (destination/'docs').mkdir();(destination/'docs/DUNA-FLEET.json').write_text(json.dumps(manifest,indent=2)+'\n')
    print(json.dumps({k:v for k,v in manifest.items() if k not in ['roles','port_pairs']},indent=2))
    if seed_zip is not None:make_fixture(root,cat,manifest,seed_zip,destination,save_name='MegaCrew Duna Fleet Prototype')

if __name__=='__main__':
    p=argparse.ArgumentParser(description=__doc__);p.add_argument('--cache',type=Path,required=True);p.add_argument('--carrier',type=Path,required=True);p.add_argument('--payloads',type=Path,required=True);p.add_argument('--output-root',type=Path,required=True);p.add_argument('--seed-zip',type=Path);a=p.parse_args();build(a.cache,a.carrier,a.payloads,a.output_root,a.seed_zip)
