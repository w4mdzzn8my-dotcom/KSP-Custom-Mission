# Hermes Duna carrier and orbital commissioning fixture

This is a **development candidate, not a playable or flight-qualified Duna expedition**.
It contains no plugin DLL, licensed game/mod assets, personal save, or server data.
Do not install it into an active game. Hamish's running Luna session is explicitly off limits.

## Included

- `Ships/VAB/Hermes Duna Carrier Prototype.craft`: new 57-part carrier.
- `GameData/MegaCrew/DunaVehicle.cfg`: two new part clones; original part definitions are unchanged. Requires SSPX Redux, Community Resource Pack and the existing FreeIVA/DeepFreeze/MegaCrew dependencies.
- `saves/MegaCrew Duna Prototype/persistent.sfs`: NEW disposable commissioning scenario in a circular 150 km Kerbin orbit, UT 100000. All four crew start awake in the command deck; engines/throttle are off and warp is disabled. This is an initial fictional setup, not a running-save conversion or mission-time advance.
- `docs/DUNA-VEHICLE-DESIGN.json`, `docs/DUNA-FIXTURE.json`: exact inventory and provenance, including explicit unverified flags.
- Reproducible generator, baseline craft and independent static audit.

The original command → quarters → lab → centrifuge → tube → adapter → cryobay attachment chain remains. Stores are aft of cryo. Preserved graph and installed FreeIVA prefab support do **not** prove walkability, collider clearance or deployed stability.

## Nominal budget

| Item | Candidate |
| --- | ---: |
| Wet mass, four crew assumed | 209.25 t |
| Nuclear engines | 4 × LV-N, 240 kN total |
| LiquidFuel / carried Oxidizer | 22,250 / 0 units |
| Ideal vacuum delta-v, leaving 15% fuel | 4,718 m/s |
| Same budget with 15 t additional payload | 4,296 m/s |
| Food / Water | 2,892 / 1,914 units |
| Food / water reserve above 720 days × 2 unfrozen crew | 33.9% / 32.9% |
| Glykerol | 150 units; planned 12 freeze events require 60 |
| Cryopod places | 10 in the existing CRY-2300 chamber |
| Stored ElectricCharge | 16,450 |
| RTG nominal generation | 6 EC/s from eight RTGs |
| Cryo holding demand, two frozen | 0.333 EC/s nominal |
| Four active radiators | 2 EC/s nominal |

Daily water includes hygiene at current campaign rates. Manual meals/drinks and extra all-awake handover time consume the finite reserve. No replenishment is added by this package. Glykerol's actual CRP density and all resource masses are included. Oxidizer capacity exists in the stock Mk3 adapters but their serialized starting amount is zero.

These are prefab/model estimates, not a solved route or thermal/power certification. Module mass changes, resource flow connectivity, crew mass, staging, actual thrust and tank accessibility require live checks. Long nuclear burns require SOI/finite-burn targeting or a qualified periapsis-kick strategy; impulsive transfer estimates cannot execute them directly. The payload sensitivity is **not** a lander design or reserved/certified lander allocation.

## Reproduce outside every game directory

Use the exact existing Hermes Walkthrough v2 craft supplied under `fixtures/`. The cache is a read-only input from a matching KSP 1.12.5 dependency profile. Output must be a new folder outside that game's root. The generator refuses existing outputs and game-directory destinations.

```sh
python3 tools/build_duna_vehicle.py \
  --cache /path/to/qa-game/GameData/ModuleManager.ConfigCache \
  --base-craft 'fixtures/Hermes Walkthrough v2.craft' \
  --seed-zip /path/to/Hermes-Practice-v0.3.0.zip \
  --output-root /path/to/new-isolated-artifact-folder

python3 tests/verify_duna_vehicle.py \
  --cache /path/to/qa-game/GameData/ModuleManager.ConfigCache \
  --base-craft 'fixtures/Hermes Walkthrough v2.craft' \
  --candidate /path/to/new-isolated-artifact-folder
```

The optional seed must match the published pristine 0.3.0 ZIP SHA-256 `0071eacf3a1b38a63c611fe2a65877ea2f62f6076b7e97d22e9cdf58b412cf40`. The archive is not included here. No personal or running save is read. The fixture deliberately does not fabricate DeepFreeze scenarios or readiness: load through normal KSP startup/scenario initialization in a future disposable QA copy.

## Evidence and remaining work

Static audit passes: one connected 57-part tree, 24 coincident stack joints with opposed normals and matching bulkhead sizes, 32 surface anchors, preserved original interior chain, finite inventories, independent mass-flow integration of ideal delta-v, safe-output refusal paths, 57 serialized save-part references, four command-deck assignments, engines/throttle off and warp disabled. This caught and corrected a craft/save identifier mismatch before packaging.

**No KSP instance was launched or controlled for this candidate.** ModuleManager's actual application of the two new clone patches, native craft/save load, deployment clearance, walking, SAS, engine behavior and fuel flow remain unverified. Source parsing is not a ModuleManager runtime test. The Duna planner remains a separate published source patch against PR12 base `6e7ac04`; this package replaces no plugin and merges no draft PR.

Next gates: inspect the actual clone prefabs in a disposable QA cache; load normally and commission at 1x; sample actual loaded/unloaded cryo power and freeze/thaw/save persistence; solve actual stock ephemerides and finite transfers within human watches; provide a dedicated atmospheric Duna lander, deployment/recovery and ascent budget plus Kerbin recovery; complete the 24-month maintenance/story sequence with one undisclosed emergency. High-rate coast remains disabled. No route, nodes, burns, campaign start, completed maintenance, frozen crew or multiplayer synchronization are fabricated in the fixture.
