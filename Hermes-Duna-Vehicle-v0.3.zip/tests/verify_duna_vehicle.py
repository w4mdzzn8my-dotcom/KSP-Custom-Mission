"""Independent static geometry/inventory audit of the exported Duna carrier.

Does not load KSP, install mods or touch any save. Runtime qualification is separate.
"""
import argparse
import collections
import hashlib
import importlib.util
import json
import math
from pathlib import Path
import subprocess
import sys
import tempfile

SPEC=importlib.util.spec_from_file_location('config_nodes',Path(__file__).resolve().parents[1]/'tools/build_landers.py')
config=importlib.util.module_from_spec(SPEC);SPEC.loader.exec_module(config)

def v(s):return tuple(map(float,s.split(',')))
def plus(a,b):return tuple(x+y for x,y in zip(a,b))
def difference(a,b):return tuple(x-y for x,y in zip(a,b))
def magnitude(a):return math.sqrt(sum(x*x for x in a))
def qrotate(q,p):
    # Independent explicit quaternion rotation matrix (generator uses cross products).
    x,y,z,w=q
    return ((1-2*y*y-2*z*z)*p[0]+2*(x*y-z*w)*p[1]+2*(x*z+y*w)*p[2],
            2*(x*y+z*w)*p[0]+(1-2*x*x-2*z*z)*p[1]+2*(y*z-x*w)*p[2],
            2*(x*z-y*w)*p[0]+2*(y*z+x*w)*p[1]+(1-2*x*x-2*y*y)*p[2])

def verify(cache_path,candidate,base):
    cache=config.parse(cache_path.read_text());cat={p.get('name'):p for n in cache.children for p in n.nodes('PART')}
    densities={p.get('name'):float(p.get('density')) for n in cache.children for p in n.nodes('RESOURCE_DEFINITION')}
    ship=candidate/'Ships/VAB/Hermes Duna Carrier Prototype.craft';root=config.parse(ship.read_text());parts=root.nodes('PART')
    report=json.loads((candidate/'docs/DUNA-VEHICLE-DESIGN.json').read_text())
    cfg_path=candidate/'GameData/MegaCrew/DunaVehicle.cfg';cfg=config.parse(cfg_path.read_text())
    clones=cfg.children
    assert len(clones)==2 and all(x.name.startswith('+PART[') and ':FINAL' in x.name for x in clones)
    # Independently apply only the two explicitly supported clone transformations.
    for c in clones:
        source=c.name.split('[',1)[1].split(']',1)[0];name=c.get('@name');cat[name]=cat[source]
    by_id={p.get('part'):p for p in parts};assert len(by_id)==len(parts)==57
    assert len({p.get('persistentId') for p in parts})==len(parts)
    order={p.get('part'):i for i,p in enumerate(parts)};parents={};adj={k:[] for k in by_id};stack=0;surface=0;totals=collections.defaultdict(float);dry=0
    def pname(p):return p.get('part').rsplit('_',1)[0].replace('.','_')
    def attach_info(p,key):
        n=cat[pname(p)];raw=v(n.get('node_stack_'+key));return raw[:3],raw[3:6],raw[6] if len(raw)>6 else 1
    for p in parts:
        key=p.get('part');q=v(p.get('rot'));assert abs(sum(x*x for x in q)-1)<1e-7
        dry+=float(cat[pname(p)].get('mass'))
        for resource in p.nodes('RESOURCE'):
            name=resource.get('name');amount=float(resource.get('amount'));cap=float(resource.get('maxAmount'))
            assert name in densities and math.isfinite(amount) and 0<=amount<=cap
            totals[name]+=amount
        for k,child in p.values:
            if k!='link':continue
            assert child in by_id and child not in parents and order[key]<order[child]
            parents[child]=key;adj[key].append(child)
        for k,link in p.values:
            if k!='attN':continue
            label,target=link.split(',',1);other_key=target.rsplit('_',1)[0]
            assert other_key in by_id
            if order[key]>order[other_key]:continue
            other=by_id[other_key];reciprocal=[val for k,val in other.values if k=='attN' and val.split(',',1)[1].rsplit('_',1)[0]==key]
            assert len(reciprocal)==1
            local,normal,size=attach_info(p,label);remote,rnormal,rsize=attach_info(other,reciprocal[0].split(',',1)[0])
            a=plus(v(p.get('pos')),qrotate(q,local));b=plus(v(other.get('pos')),qrotate(v(other.get('rot')),remote))
            assert magnitude(difference(a,b))<1e-5,(key,other_key,a,b)
            assert size==rsize
            assert sum(x*y for x,y in zip(qrotate(q,normal),qrotate(v(other.get('rot')),rnormal)))<-.99999
            stack+=1
        links=[value for k,value in p.values if k=='srfN']
        if links:
            assert len(links)==1;parent=by_id[links[0].split(',',1)[1]];raw=v(cat[pname(p)].get('node_attach'))
            point=plus(v(p.get('pos')),qrotate(q,raw[:3]));assert abs(math.hypot(point[0],point[2])-1.875)<1e-6
            normal=qrotate(q,raw[3:6]);assert sum(x*y for x,y in zip(normal,(point[0]/1.875,0,point[2]/1.875)))<-.99999
            assert abs(point[1]-v(parent.get('pos'))[1])<=2.00001
            surface+=1
    assert len(parents)==len(parts)-1 and parts[0].get('part') not in parents
    assert stack==24 and surface==32 and stack+surface==len(parts)-1
    # Entire original required interior chain remains contiguous ahead of the stores.
    chain=[];p=parts[0]
    for expected in ['MegaCrewDunaBridge','sspx-habitation-375-1','sspx-lab-375-1','sspx-expandable-centrifuge-375-1','sspx-tube-375-1','sspx-adapter-25-375-2','CRY-2300Freezer']:
        assert pname(p)==expected;chain.append(p.get('part'))
        if expected!='CRY-2300Freezer':p=next(by_id[k] for k in adj[p.get('part')] if not by_id[k].get('srfN'))
    assert collections.Counter(pname(p) for p in parts)['nuclearEngine']==4
    assert not any(pname(p).startswith(('liquidEngine','RadialDecoupler')) for p in parts)
    assert totals['Oxidizer']==0 and totals['Glykerol']==150 and totals['MonoPropellant']==400
    assert totals['Food']>=2160*1.3 and totals['Water']>=1440*1.3 and totals['ElectricCharge']>=4*3000
    store=next(p for p in parts if pname(p)=='MegaCrewDunaStores')
    declared={r.get('name'):float(r.get('amount')) for r in clones[1].nodes('RESOURCE')}
    assert declared=={r.get('name'):float(r.get('amount')) for r in store.nodes('RESOURCE')}
    assert any(n.name.startswith('!MODULE[ModuleB9PartSwitch]:HAS[#moduleID[cargoSwitch]]') for n in clones[1].children)
    assert clones[0].nodes('MODULE')[0].get('name')=='ModuleSAS' and clones[0].nodes('MODULE')[0].get('SASServiceLevel')=='3'
    wet=dry+.375+sum(densities[k]*x for k,x in totals.items());final=wet-.85*totals['LiquidFuel']*densities['LiquidFuel']
    assert abs(wet-report['wet_with_four_crew_t'])<1e-8
    # Independent constant-step mass-flow integration, rather than direct log evaluation.
    steps=200000;dm=(wet-final)/steps;dv=sum(800*9.80665*dm/(wet-(i+.5)*dm) for i in range(steps))
    assert abs(dv-report['ideal_delta_v_to_15_percent_reserve_m_s'])<1e-5
    assert report['resources']==dict(totals) and report['runtime_verified'] is False and report['mission_playable'] is False
    for path,key in [(ship,'craft_sha256'),(cfg_path,'custom_parts_cfg_sha256'),(cache_path,'input_cache_sha256')]:assert hashlib.sha256(path.read_bytes()).hexdigest()==report[key]
    # Audit the NEW orbital fixture's serialized graph and safe initial state.
    save=candidate/'saves/MegaCrew Duna Prototype/persistent.sfs'
    if save.exists():
        game=config.parse(save.read_text()).nodes('GAME')[0];flight=game.nodes('FLIGHTSTATE')[0];vessel=flight.nodes('VESSEL')[0]
        snapshots=vessel.nodes('PART');assert len(snapshots)==len(parts)
        assert flight.get('UT')=='100000' and vessel.get('sit')=='ORBITING'
        orbit=vessel.nodes('ORBIT')[0];assert orbit.get('REF')=='1' and orbit.get('SMA')=='750000' and orbit.get('ECC')=='0'
        rules=game.nodes('PARAMETERS')[0].nodes('FLIGHT')[0];assert rules.get('CanTimeWarpHigh')=='False' and rules.get('CanTimeWarpLow')=='False'
        roster=[n.get('name') for n in game.nodes('ROSTER')[0].nodes('KERBAL')]
        assert [value for k,value in snapshots[0].values if k=='crew']==roster
        assert not any(k=='crew' for p in snapshots[1:] for k,value in p.values)
        assert len(roster)==4 and len(roster)<=int(cat['MegaCrewDunaBridge'].get('CrewCapacity'))
        for i,(p,snapshot) in enumerate(zip(parts,snapshots)):
            assert snapshot.get('name')==pname(p)
            assert int(snapshot.get('parent'))==order[parents[p.get('part')]] if i else snapshot.get('parent')=='0'
            assert magnitude(difference(v(snapshot.get('position')),difference(v(p.get('pos')),v(parts[0].get('pos')))))<1e-5
            assert snapshot.get('uid')==p.get('part').rsplit('_',1)[1]
            for module in snapshot.nodes('MODULE'):
                if module.get('name') in ('ModuleEngines','ModuleEnginesFX'):assert module.get('EngineIgnited')=='False' and module.get('currentThrottle')=='0'
            assert {r.get('name'):r.get('amount') for r in snapshot.nodes('RESOURCE')}=={r.get('name'):r.get('amount') for r in p.nodes('RESOURCE')}
        fixture=json.loads((candidate/'docs/DUNA-FIXTURE.json').read_text())
        assert hashlib.sha256(save.read_bytes()).hexdigest()==fixture['persistent_sfs_sha256'] and fixture['in_game_load_verified'] is False
        print('PASS: new 150 km Kerbin commissioning save; 57 serialized parts and parent references; four crew assigned to command; engines/throttle off; warp disabled; no fabricated campaign/cryo scenario.')
    # Exercise refusal paths using only disposable inputs: never target a game directory.
    tool=Path(__file__).resolve().parents[1]/'tools/build_duna_vehicle.py'
    with tempfile.TemporaryDirectory() as scratch:
        scratch=Path(scratch);c=scratch/'fake-game/GameData/ModuleManager.ConfigCache';c.parent.mkdir(parents=True);c.write_text('')
        for destination in [candidate,scratch/'fake-game/forbidden-output']:
            run=subprocess.run([sys.executable,str(tool),'--cache',str(c),'--base-craft',str(base),'--output-root',str(destination)],capture_output=True,text=True)
            assert run.returncode!=0
        assert not (scratch/'fake-game/forbidden-output').exists()
    print('PASS: 57-part connected tree; 24 exact stack joints; 32 surface anchors; original interior chain; finite inventories; independent mass-flow delta-v; output refusal guards. Static only, no gameplay verification.')

if __name__=='__main__':
    p=argparse.ArgumentParser();p.add_argument('--cache',type=Path,required=True);p.add_argument('--candidate',type=Path,required=True);p.add_argument('--base-craft',type=Path,required=True);a=p.parse_args();verify(a.cache,a.candidate,a.base_craft)
